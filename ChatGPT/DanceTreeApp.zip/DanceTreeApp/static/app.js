/* static/app.js
   JavaScript-Frontend-Logik für die DanceTreeApp.

   Verantwortlichkeiten:
   - Lädt die Struktur vom Backend-Endpunkt /tree?file=...
   - Baut eine einfache Figurenliste (links) und eine Baumdarstellung (rechts)
   - Zeigt Statusmeldungen in der Toolbar
   - Die zentrale Tanzfläche bleibt leer (Platzhalter) — spätere Implementierung
*/

/**
 * Hilfsfunktion: holt die Tree-Daten vom Server.
 * Erwartet eine flache Node-Liste (id, parent_id, name, type, meta).
 */
async function fetchTree(filename) {
  const url = '/tree?file=' + encodeURIComponent(filename);
  const res = await fetch(url);
  if (!res.ok) {
    const err = await res.json().catch(()=>({error:res.statusText}));
    throw new Error(err.error || res.statusText || 'Fehler beim Laden');
  }
  return await res.json();
}

/**
 * Baut aus einer flachen Node-Liste eine verschachtelte Struktur.
 * Gibt das Root-Objekt zurück (das parent_id === null hat).
 */
function buildNested(nodes) {
  const map = new Map();
  nodes.forEach(n => map.set(n.id, {...n, children: []}));
  let root = null;
  map.forEach(n => {
    if (n.parent_id === null) {
      root = n;
    } else if (map.has(n.parent_id)) {
      map.get(n.parent_id).children.push(n);
    }
  });
  return root;
}

/**
 * Rendert die Figurenliste auf der linken Seite.
 * Wir filtern hier einfache/spezifische Knoten (z. B. type === 'simple'), zeigen
 * aber standardmäßig alle Knoten an, falls 'type' nicht gesetzt ist.
 */
function renderFigureList(nodes) {
  const ul = document.getElementById('figureList');
  ul.innerHTML = '';
  nodes.forEach(n => {
    const li = document.createElement('li');
    const title = document.createElement('div');
    title.textContent = n.name || ('Knoten ' + n.id);
    const meta = document.createElement('div');
    meta.style.fontSize = '0.85em';
    meta.style.color = '#666';
    meta.textContent = n.type ? ('Typ: ' + n.type) : '';
    li.appendChild(title);
    li.appendChild(meta);
    ul.appendChild(li);
  });
}

/**
 * Rekursiv: rendert den Baum (rechte Spalte) als verschachtelte <ul>.
 */
function renderTree(node) {
  if (!node) return document.createTextNode('(keine Struktur)');
  const container = document.createElement('div');
  const rootUl = document.createElement('ul');

  function makeLi(n) {
    const li = document.createElement('li');
    const title = document.createElement('div');
    title.textContent = n.name + ' (id:' + n.id + ')';
    title.style.fontWeight = '600';
    const meta = document.createElement('div');
    meta.style.fontSize = '0.85em';
    meta.style.color = '#666';
    meta.textContent = Object.keys(n.meta || {}).length ? JSON.stringify(n.meta) : '';
    li.appendChild(title);
    if (meta.textContent) li.appendChild(meta);

    if (n.children && n.children.length) {
      const subUl = document.createElement('ul');
      n.children.forEach(ch => subUl.appendChild(makeLi(ch)));
      li.appendChild(subUl);
    }
    return li;
  }

  rootUl.appendChild(makeLi(node));
  container.appendChild(rootUl);
  return container;
}

/**
 * Setzt einen kurzen Statustext in der Toolbar.
 */
function setStatus(text) {
  const el = document.getElementById('status');
  if (el) el.textContent = text;
}

/**
 * Haupt-Load-Funktion: liest den Dateinamen aus dem Input-Feld,
 * ruft fetchTree auf und füllt die Bereiche.
 */
async function loadAndRender() {
  const input = document.getElementById('fileInput');
  const fname = input.value.trim() || 'HLReelAD.json';
  setStatus('Lade ' + fname + ' ...');
  try {
    const nodes = await fetchTree(fname);
    // nodes ist eine flache Liste; wir bauen daraus eine verschachtelte Struktur
    renderFigureList(nodes || []);
    const root = buildNested(nodes || []);
    const treeContainer = document.getElementById('treeContainer');
    treeContainer.innerHTML = '';
    treeContainer.appendChild(renderTree(root));
    setStatus('Datei geladen: ' + fname);
  } catch (err) {
    console.error(err);
    setStatus('Fehler: ' + err.message);
    // Wenn Fehler, zeige kurze Nachricht im Tree-Container
    const treeContainer = document.getElementById('treeContainer');
    treeContainer.innerHTML = '<div style="color:crimson">Fehler: ' + err.message + '</div>';
    const ul = document.getElementById('figureList');
    ul.innerHTML = '';
  }
}

/**
 * Event-Handler: Klick auf den 'Laden'-Button
 */
document.addEventListener('DOMContentLoaded', function() {
  document.getElementById('loadButton').addEventListener('click', loadAndRender);
  // Laden beim ersten Aufruf
  loadAndRender();
});
