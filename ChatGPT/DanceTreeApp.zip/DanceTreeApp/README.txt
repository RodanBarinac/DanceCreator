DanceTreeApp - README
=====================

Dieses Paket enthält eine einfache Flask-Anwendung + HTML5-Frontend, die als Ausgangspunkt
für die DanceCreator-GUI verwendet werden kann.

Dateien:
 - dance_tree_app.py        : Flask-Backend (API /tree, und Servieren der index.html)
 - templates/index.html     : HTML-Layout (Toolbar, Figurenliste, Platzhalter-Tanzfläche, Baum)
 - static/style.css         : CSS für das Layout
 - static/app.js            : JS-Frontend: lädt /tree?file=... und zeigt Figuren + Baum
 - Figures/                 : Verzeichnis für JSON-Dateien (leeres Verzeichnis in diesem ZIP)

Schnellstart:
1) Lege deine JSON-Dateien (z.B. HLReelAD.json) in das Verzeichnis 'Figures'.
2) Installiere Flask: pip install flask
3) Starte die App: python dance_tree_app.py
4) Öffne http://127.0.0.1:5000 in deinem Browser

Hinweis:
 - Die Tanzfläche ist aktuell ein Platzhalter. Drag&Drop und Bearbeitung werden später implementiert.
 - Wenn du die Dateien in ein bestehendes Projekt integrieren willst, kopiere templates/index.html nach /templates
   und die Dateien in /static in deinen statischen Ordner. Passe ggf. den Pfad 'Figures' in dance_tree_app.py an.
