/* static/app.js
   JavaScript-Frontend-Logik für die DanceTreeApp (Lazy Loading + Auto Expand).
*/

async function fetchTree(filename) {
  const url = '/tree?file=' + encodeURIComponent(filename);
  const res = await fetch(url);
  if (!res.ok) throw new Error('Fehler beim Laden');
  return await res.json();
}

async function fetchTreeChildren(filename, parentId) {
  const url = '/tree_children?file=' + encodeURIComponent(filename) + '&parent_id=' + encodeURIComponent(parentId);
  const res = await fetch(url);
  if (!res.ok) throw new Error('Fehler beim Nachladen');
  return await res.json();
}

function renderJsTreeLazy(filename) {
  const treeContainer = $('#treeContainer');
  treeContainer.jstree('destroy');
  treeContainer.jstree({
    core: {
      data: function (obj, cb) {
        if (obj.id === '#') {
          fetchTree(filename).then(nodes => {
            const data = nodes.map(n => ({
              id: n.id,
              parent: n.parent_id === null ? '#' : n.parent_id,
              text: n.name || ('Knoten ' + n.id),
              type: n.type || 'default',
              data: n.meta || {},
              children: n.has_subfigures || false
            }));
            cb(data);
          });
        } else {
          fetchTreeChildren(filename, obj.id).then(nodes => {
            const data = nodes.map(n => ({
              id: n.id,
              parent: n.parent_id === null ? '#' : n.parent_id,
              text: n.name || ('Knoten ' + n.id),
              type: n.type || 'default',
              data: n.meta || {},
              children: n.has_subfigures || false
            }));
            cb(data);
          });
        }
      },
      check_callback: true
    },
    plugins: ['types', 'wholerow'],
    types: {
      default: { icon: 'jstree-icon jstree-file' },
      simple: { icon: 'jstree-icon jstree-file' },
      complex: { icon: 'jstree-icon jstree-folder' }
    }
  });

  // --- Automatisch alle Knoten expandieren ---
  treeContainer.on('loaded.jstree', function() {
    const tree = $(this).jstree(true);
    const openAll = async function(nodeId) {
      const node = tree.get_node(nodeId);
      if (!node) return;
      if (node.children === true) {
        await new Promise(resolve => tree.open_node(node, resolve));
      } else if (node.children.length > 0) {
        tree.open_node(node);
      }
      for (const cid of node.children) {
        await openAll(cid);
      }
    };
    const root = tree.get_node('#').children;
    (async () => {
      for (const id of root) await openAll(id);
    })();
  });
}

async function fetchAndRenderFigureList() {
  const ul = document.getElementById('figureList');
  ul.innerHTML = '<li>Lade Figuren ...</li>';
  try {
    const res = await fetch('/figures');
    const figures = await res.json();
    ul.innerHTML = '';
    const simple = figures.filter(f => f.type === 'simple').sort((a,b)=>a.name.localeCompare(b.name));
    const complex = figures.filter(f => f.type === 'complex').sort((a,b)=>a.name.localeCompare(b.name));
    if (simple.length) {
      const h = document.createElement('li');
      h.textContent = 'Einfache Figuren:';
      h.style.fontWeight = 'bold';
      ul.appendChild(h);
      simple.forEach(f => { const li=document.createElement('li'); li.textContent=f.name; ul.appendChild(li); });
    }
    if (complex.length) {
      const h = document.createElement('li');
      h.textContent = 'Komplexe Figuren:';
      h.style.fontWeight = 'bold';
      ul.appendChild(h);
      complex.forEach(f => { const li=document.createElement('li'); li.textContent=f.name; ul.appendChild(li); });
    }
  } catch (err) {
    ul.innerHTML = '<li>Fehler: ' + err.message + '</li>';
  }
}

function setStatus(text) {
  const el = document.getElementById('status');
  if (el) el.textContent = text;
}

async function loadAndRender() {
  const input = document.getElementById('fileInput');
  let fname = input.value.trim() || 'HLReelAD';
  if (!fname.endsWith('.json')) fname += '.json';
  setStatus('Lade ' + fname + ' ...');
  try {
    fetchAndRenderFigureList();
    renderJsTreeLazy(fname);
    setStatus('Datei geladen: ' + fname);
  } catch (err) {
    setStatus('Fehler: ' + err.message);
  }
}

document.addEventListener('DOMContentLoaded', function() {
  document.getElementById('loadButton').addEventListener('click', loadAndRender);
  loadAndRender();
});
