// Platzhalter für das komplette JavaScript (siehe Canvas-Dokument)
console.log("DanceCreator webapp loaded");