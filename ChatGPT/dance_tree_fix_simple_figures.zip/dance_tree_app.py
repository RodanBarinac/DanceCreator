from flask import Flask, jsonify, request, render_template
import json, os
from itertools import count
from typing import Any, Dict, List, Optional

app = Flask(__name__, template_folder="templates", static_folder="static")
FIGURES_DIR = os.path.join(os.path.dirname(__file__), "Figures")

def find_complex_figures() -> set:
    complex_names = set()
    if not os.path.isdir(FIGURES_DIR):
        return complex_names
    for fname in os.listdir(FIGURES_DIR):
        if not fname.endswith(".json"):
            continue
        path = os.path.join(FIGURES_DIR, fname)
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict) and "FigureList" in data:
                    complex_names.add(fname[:-5])
        except Exception:
            continue
    return complex_names

def build_tree_from_json(data: Any, external_files: Optional[set] = None, loaded_files: Optional[set] = None) -> List[Dict[str, Any]]:
    id_gen = count(1)
    nodes: List[Dict[str, Any]] = []

    if external_files is None:
        external_files = find_complex_figures()
    if loaded_files is None:
        loaded_files = set()

    def new_node(name: str, parent: Optional[int], node_type: str, meta: Optional[Dict]=None) -> int:
        nid = next(id_gen)
        node = {
            "id": nid,
            "parent_id": parent,
            "name": name,
            "type": node_type,
            "meta": meta or {}
        }
        # Nur komplexe externe Figuren markieren
        if name in external_files and name not in loaded_files:
            node["has_subfigures"] = True
            node["external_figure"] = True
        nodes.append(node)
        return nid

    def parse_item(item: Any, parent: Optional[int]) -> None:
        if item is None:
            return
        if isinstance(item, dict):
            name = item.get("Name") or item.get("name") or "Figure"
            nid = new_node(name, parent, "complex", {k:v for k,v in item.items() if k != "FigureList"})
            if "FigureList" in item:
                parse_item(item["FigureList"], nid)
            return
        if isinstance(item, list):
            if len(item) == 2 and isinstance(item[0], str) and isinstance(item[1], list):
                mode = item[0]
                nid = new_node(f"Complex ({mode})", parent, "complex", {"mode": mode})
                for sub in item[1]:
                    parse_item(sub, nid)
                return
            if len(item) == 2 and isinstance(item[0], list) and (isinstance(item[1], list) or isinstance(item[1], str)):
                anchor = item[0]
                if isinstance(item[1], list):
                    name = item[1][0] if item[1] else "Figure"
                    addons = item[1][1:] if len(item[1]) > 1 else []
                else:
                    name = item[1]
                    addons = []
                new_node(name, parent, "simple", {"anchor": anchor, "addons": addons})
                return
            for sub in item:
                parse_item(sub, parent)
            return
        new_node(str(item), parent, "unknown", {"raw": item})

    root_name = "Dance"
    if isinstance(data, dict):
        root_name = data.get("Name", root_name)
    root_id = new_node(root_name, None, "root", {})
    if isinstance(data, dict) and "FigureList" in data:
        parse_item(data["FigureList"], root_id)
    else:
        parse_item(data, root_id)
    return nodes

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/tree")
def tree():
    fname = request.args.get("file") or "HLReelAD.json"
    path = os.path.join(FIGURES_DIR, fname)
    data = None
    if os.path.isfile(path):
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    if not data:
        return jsonify([{"id":1,"parent_id":None,"name":"(leer)","type":"root","meta":{}}])
    nodes = build_tree_from_json(data)
    return jsonify(nodes)

@app.route("/tree_children")
def tree_children():
    fname = request.args.get("file") or "HLReelAD.json"
    parent_id = request.args.get("parent_id")
    if parent_id is None:
        return jsonify([])

    path = os.path.join(FIGURES_DIR, fname)
    data = None
    if os.path.isfile(path):
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    if not data:
        return jsonify([])

    loaded_files = {fname[:-5]} if fname.endswith(".json") else {fname}
    nodes = build_tree_from_json(data, loaded_files=loaded_files)
    parent_node = next((n for n in nodes if str(n["id"]) == str(parent_id)), None)

    if parent_node and parent_node.get("external_figure"):
        ext_name = parent_node["name"]
        ext_file = os.path.join(FIGURES_DIR, ext_name + ".json")
        if os.path.isfile(ext_file) and ext_name not in loaded_files:
            with open(ext_file, encoding="utf-8") as f:
                ext_data = json.load(f)
            ext_loaded_files = set(loaded_files)
            ext_loaded_files.add(ext_name)
            ext_nodes = build_tree_from_json(ext_data, loaded_files=ext_loaded_files)
            ext_root = next((n for n in ext_nodes if n["parent_id"] is None), None)
            if ext_root:
                children = [n for n in ext_nodes if n["parent_id"] == ext_root["id"]]
                for n in children:
                    n["id"] = str(n["id"]); n["parent_id"] = str(n["parent_id"]) if n["parent_id"] else None
                return jsonify(children)
        return jsonify([])

    children = [n for n in nodes if str(n.get("parent_id")) == str(parent_id)]
    for n in children:
        n["id"] = str(n["id"]); n["parent_id"] = str(n["parent_id"]) if n["parent_id"] else None
    return jsonify(children)

@app.route("/figures")
def figures():
    result = []
    if not os.path.isdir(FIGURES_DIR):
        return jsonify(result)
    for fname in sorted(os.listdir(FIGURES_DIR)):
        if not fname.endswith(".json"):
            continue
        path = os.path.join(FIGURES_DIR, fname)
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
            name = data.get("Name", fname[:-5])
            desc = data.get("Desc", "")
            ftype = "complex" if "FigureList" in data else "simple"
            result.append({"name": name, "desc": desc, "type": ftype, "filename": fname})
        except Exception:
            continue
    return jsonify(result)

if __name__ == "__main__":
    os.makedirs(FIGURES_DIR, exist_ok=True)
    print("Starte DanceTreeApp mit einfacher/komplexer Figurenunterscheidung...")
    app.run(debug=True)
